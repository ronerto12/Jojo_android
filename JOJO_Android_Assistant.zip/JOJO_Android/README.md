# JOJO Android Assistant

Native Android starter for a real phone assistant architecture.

## What is included
- Native Android Kotlin app
- Text + microphone input
- Hindi/Hinglish TTS
- Gemini via your existing Netlify backend (no API key in APK)
- YouTube / Spotify / WhatsApp / Maps / browser / Settings / dialer actions
- Android VoiceInteractionService + VoiceInteractionSessionService declaration
- Local conversation context during the app session

## Setup
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android phone.
4. Grant microphone permission.
5. Keep your Gemini API key on the Netlify function, not in this app.
6. In Android Settings, choose JOJO AI as the default digital assistant if your device exposes that option.

## Important
The assistant can launch apps/actions through Android Intents. Sending messages or placing calls should remain user-confirmed. Android/OEM versions can expose different assistant settings and restrictions.

The `GeminiClient` endpoint currently points to the Netlify function URL used by the previous JOJO project. Change it if your backend URL is different.
