package com.jojo.assistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri

class ActionManager(private val context: Context) {
    private fun open(uri: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun youtube(query: String? = null) = open(if (query.isNullOrBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
    fun spotify(query: String? = null) = open(if (query.isNullOrBlank()) "https://open.spotify.com" else "https://open.spotify.com/search/${Uri.encode(query)}")
    fun whatsapp(text: String? = null) = open(if (text.isNullOrBlank()) "https://wa.me/" else "https://wa.me/?text=${Uri.encode(text)}")
    fun browser(url: String) = open(if (url.startsWith("http")) url else "https://www.google.com/search?q=${Uri.encode(url)}")
    fun dial(number: String) { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun maps(query: String) = open("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")
    fun settings() { context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun app(packageName: String) { context.packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let(context::startActivity) }

    fun tryCommand(command: String): Boolean {
        val c = command.lowercase().trim()
        return when {
            c == "youtube kholo" || c.contains("youtube open") -> { youtube(); true }
            c.startsWith("youtube search ") -> { youtube(c.removePrefix("youtube search ")); true }
            c == "spotify kholo" || c.contains("spotify open") -> { spotify(); true }
            c == "whatsapp kholo" || c.contains("whatsapp open") -> { whatsapp(); true }
            c.startsWith("whatsapp message ") -> { whatsapp(c.removePrefix("whatsapp message ")); true }
            c == "settings kholo" || c == "settings open" -> { settings(); true }
            c.startsWith("maps ") -> { maps(c.removePrefix("maps ")); true }
            c.startsWith("dial ") -> { dial(c.removePrefix("dial ").filter { it.isDigit() || it == '+' }); true }
            c.startsWith("browser ") -> { browser(c.removePrefix("browser ")); true }
            else -> false
        }
    }
}
