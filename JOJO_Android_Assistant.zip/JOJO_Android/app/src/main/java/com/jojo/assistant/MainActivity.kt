package com.jojo.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.jojo.assistant.actions.ActionManager
import com.jojo.assistant.ai.GeminiClient
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText; private lateinit var chat: TextView; private lateinit var tts: TextToSpeech
    private val ai = GeminiClient(); private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val history = mutableListOf<Pair<String,String>>()
    private val reqVoice = 77

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi(); tts = TextToSpeech(this, this); if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), reqVoice) }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,42,28,28); setBackgroundColor(android.graphics.Color.rgb(8,11,18)) }
        val title = TextView(this).apply { text="JOJO AI\nPERSONAL ANDROID ASSISTANT"; textSize=24f; setTextColor(android.graphics.Color.WHITE); setPadding(0,0,0,20) }
        chat = TextView(this).apply { text="JOJO: Ready. Type or speak your command."; textSize=16f; setTextColor(android.graphics.Color.LTGRAY); setPadding(0,10,0,10) }
        val scroll = ScrollView(this).apply { addView(chat); layoutParams=LinearLayout.LayoutParams(-1,0,1f) }
        input = EditText(this).apply { hint="Type to JOJO..."; setTextColor(android.graphics.Color.WHITE); setHintTextColor(android.graphics.Color.GRAY); setSingleLine(true) }
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val send=Button(this).apply { text="SEND"; setOnClickListener { sendText() } }
        val mic=Button(this).apply { text="🎙️"; setOnClickListener { listen() } }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(mic); row.addView(send)
        root.addView(title); root.addView(scroll); root.addView(row); setContentView(root)
    }
    private fun sendText() { val s=input.text.toString().trim(); if(s.isEmpty()) return; input.setText(""); handle(s) }
    private fun handle(s:String) { chat.append("\n\nYOU: $s"); val actions=ActionManager(this); if(actions.tryCommand(s)){ speak("Done."); chat.append("\nJOJO: Done."); return }; scope.launch { try { val a=ai.ask(s,history); history.add("user" to s); history.add("assistant" to a); chat.append("\nJOJO: $a"); speak(a) } catch(e:Exception){ chat.append("\nJOJO: Error: ${e.message}"); speak("Sorry, abhi problem aa rahi hai.") } } }
    private fun listen(){ val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); putExtra(RecognizerIntent.EXTRA_PROMPT,"JOJO ko bolo...") }; try { startActivityForResult(i,1001) } catch(_:Exception){ Toast.makeText(this,"Voice recognition available nahi hai",Toast.LENGTH_SHORT).show() } }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==1001 && resultCode==RESULT_OK){ data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(::handle) } }
    private fun speak(s:String){ if(::tts.isInitialized) { tts.stop(); tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jojo") } }
    override fun onInit(status:Int){ if(status==TextToSpeech.SUCCESS){ tts.language=Locale("hi","IN"); tts.setSpeechRate(.88f); tts.setPitch(.92f) } }
    override fun onDestroy(){ scope.cancel(); if(::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
