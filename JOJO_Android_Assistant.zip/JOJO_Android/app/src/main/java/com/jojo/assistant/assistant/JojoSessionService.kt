package com.jojo.assistant.assistant

import android.content.Context
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class JojoSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle): VoiceInteractionSession = JojoSession(this)
}

class JojoSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        // The system launches this session when JOJO is selected as the device assistant.
        // Full conversational UI can be expanded here; the main app remains the primary UI.
    }
}
