package com.jojo.assistant.assistant

import android.os.Bundle
import android.service.voice.VoiceInteractionService

class JojoVoiceService : VoiceInteractionService() {
    override fun onReady() { super.onReady(); setInvocationEffectEnabled(true) }
    override fun onPrepareToShowSession(args: Bundle, flags: Int) { showSession(args, flags) }
}
