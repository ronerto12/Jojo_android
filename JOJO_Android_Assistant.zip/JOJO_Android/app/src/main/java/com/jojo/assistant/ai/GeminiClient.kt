package com.jojo.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiClient {
    // IMPORTANT: keep the Gemini key on your Netlify/server backend, not inside the APK.
    private val endpoint = "https://mriacalwedding.netlify.app/.netlify/functions/jojo"

    suspend fun ask(text: String, history: List<Pair<String,String>> = emptyList()): String = withContext(Dispatchers.IO) {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        val arr = org.json.JSONArray()
        history.takeLast(12).forEach { (role, content) ->
            arr.put(JSONObject().put("role", role).put("content", content))
        }
        val body = JSONObject().put("message", text).put("history", arr)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.readText().orEmpty()
        if (conn.responseCode !in 200..299) throw Exception(JSONObject(raw).optString("error", "AI server error"))
        JSONObject(raw).optString("answer", "Mujhe response nahi mila.")
    }
}
